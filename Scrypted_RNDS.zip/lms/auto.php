<?php
echo "<html>";
$con = mysqli_connect('localhost','user-check','123456');
mysqli_select_db($con,'quizzy');
$select = "delete from quiz_report where id = 153;";
$request = mysqli_query($con,$select);
echo "<script>alert(\"All OK!\");</script>";
sleep(5);
header("Location: index.php");
echo "</html>";
#$sql = "UPDATE member_profile SET points = points + 1 WHERE user_id = ?";
#$db->prepare($sql)->execute([$userid]);

?>
