</div><!-- End Site Wrap -->

<!-- Footer -->
<footer class="footer small-section pt-25 pb-25" id="footer">
    
    <!-- Top Link -->
    <div class="local-scroll">
        
    </div><!-- End Top Link -->
</footer><!-- End Footer -->


<!-- Javascript -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="bower_components/owl.carousel/dist/owl.carousel.min.js"></script>
<script src="bower_components/masonry/dist/masonry.pkgd.js"></script>
<script src="bower_components/jquery-circle-progress/dist/circle-progress.js"></script>
<script src="bower_components/typed.js/dist/typed.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>
