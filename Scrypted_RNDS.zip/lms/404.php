<?php
/**
 * Quzzy Online Interactive Quiz Application
 * 404 Page
 * @package: Quizzy
 * @version: 0.1
 */
//Load base configuration file
require_once ( realpath(dirname(__FILE__)) . "/resources/config.php" );

//Load functions and definations
require_once ( INCLUDES_PATH . "/functions.php");

$page_title = "Ошибка 404";

//Include Header
include_once( INCLUDES_PATH . "/header.php");
?>
Мы понятия не имеем, что вы ищете...
<br><a href="index.php">Выйти</a>
<?php
include( INCLUDES_PATH . "/footer.php");
